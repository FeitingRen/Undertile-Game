| resource      | author      | licence | notes |
| :------------ | :---------: | :------ | :---- |
| ps3.png       | [@raysan5](https://github.com/raysan5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | - |
| xbox.png      | [@raysan5](https://github.com/raysan5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | - |
